#!/usr/bin/env python
# coding: utf-8

# In[ ]:


a = set()
[a.add(input()) for _ in range(int(input()))]
print(len(a))

