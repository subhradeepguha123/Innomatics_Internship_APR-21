#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#Q-1:Find the Runner-Up Score!

if __name__ == '__main__':
    n = int(input())
    arr = map(int, input().split())
    print(sorted(list(set(arr)))[-2])


# In[ ]:





# In[ ]:




